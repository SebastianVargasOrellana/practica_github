Var1=float(input("Introduce el primernúmero"))
Var2=float(input("Introduce el valor del segundo número"))
total=Var1 + Var2
print("El resultado de la suma de", Var1, "más",Var2, "es" , total)
