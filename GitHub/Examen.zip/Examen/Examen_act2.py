Var1=float(input("Introduce el primernúmero"))
Var2=float(input("Introduce el valor del segundo número"))
total=Var1 + Var2
division=round(total/3,3)
print("El resultado de la suma de", Var1, "más",Var2, "es" , total)
print("El resultado de dividir ", total, "entre 3 es", division)