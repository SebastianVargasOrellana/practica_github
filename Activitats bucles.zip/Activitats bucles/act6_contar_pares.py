#Crea un programa que cuente todos los números pares hasta el número 50
impares=0
pares=0
for i in range (0,50,2):
    pares+=1
for i in range (1,50,2):
    impares+=1
print(pares, impares)